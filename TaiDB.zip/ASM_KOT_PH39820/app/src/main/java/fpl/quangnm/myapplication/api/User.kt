package fpl.quangnm.myapplication.api

data class User(
    val name: String,
    val username: String,
    val email: String,
    val password: String
)





