package fpl.quangnm.myapplication.api

data class LoginRequest(
    val username: String,
    val password: String
)
